import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Product } from '../products/product';

@Component({
  selector: 'app-single-product',
  templateUrl: './single-product.component.html',
  styleUrls: ['./single-product.component.css']
})
export class SingleProductComponent implements OnInit {
  productHeading:string='Search Product Details';
  error:string;
  productId:number;
  product:Product;
  constructor(private productService:ProductService) { 
    this.productId=0;
  }

  /*get productId1():number{
    return this.productId;
  }
  set productId1(value:number){
    this.productId=value;
  }
  */
  getProduct(data){
    this.productService.getProductDetails(data.productId).subscribe(
      tempProduct=>{
        this.product=tempProduct;
      }
    ,
      error=>{
        this.error=error;
      }
  );
  }

  ngOnInit() {
  }

}
