import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductsListComponent } from './products/products-list.component';
import { ConvertToSpacePipe } from './shared/convert-to-space.pipe';
import { StarComponent } from './shared/star.component';
import { HttpClientModule } from '@angular/common/http'
import { ProductService } from './services/product.service';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule } from '@angular/router';
import { SingleProductComponent } from './singleProduct/single-product.component';
import { ProductdetailsComponent } from './products/productdetails/productdetails.component';
import { DeleteProductComponent } from './products/deleteProduct/delete-product.component';
import { AddProductComponent } from './products/addProduct/add-product.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductsListComponent,
    ConvertToSpacePipe,
    StarComponent,
    WelcomeComponent,
    SingleProductComponent,
    ProductdetailsComponent,
    DeleteProductComponent,
    AddProductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'products', component: ProductsListComponent},
      {path: 'welcome', component: WelcomeComponent},
      {path: 'singleProduct', component: SingleProductComponent},
      {path: 'product/:id', component: ProductdetailsComponent},
      {path: 'deleteProduct/:id', component: DeleteProductComponent},
      {path: 'addProduct', component: AddProductComponent},
      {path: '', redirectTo: 'welcome', pathMatch: 'full'}
    ])
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
