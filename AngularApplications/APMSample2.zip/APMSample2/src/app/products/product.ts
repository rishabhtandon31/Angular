export interface Product {
    productId: number;
    productname: String;
    productCode:String;
    releaseDate: string;
    description: string;
    price: number,
    starRating: number;
}
