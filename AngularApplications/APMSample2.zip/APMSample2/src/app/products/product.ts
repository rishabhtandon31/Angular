export interface Product {
    productId: number;
    productName: String;
    productCode:String;
    releaseDate: string;
    description: string;
    price: number,
    starRating: number;
}
