import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import { Product } from '../product';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  pageTitle:string="Add Product Details";
  productId:number;
  price:number;
  starRating:number;
  productCode:string;
  description:string;
  productName:string;
  releaseDate:string;
  errorMessage: string;
  addMessage:string;
  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) { }
  
  get productId1():number{
    return this.productId;
  }
  set productId1(value:number){
    this.productId=value;
  }
  get price1():number{
    return this.price;
  }
  set price1(value:number){
    this.price=value;
  }
  get starRating1():number{
    return this.starRating;
  }
  set starRating1(value:number){
    this.starRating=value;
  }
  get productCode1():string{
    return this.productCode;
  }
  set productCode1(value:string){
    this.productCode=value;
  }
  get description1():string{
    return this.description;
  }
  set description1(value:string){
    this.description=value;
  }
  get productName1():string{
    return this.productName;
  }
  set productName1(value:string){
    this.productName=value;
  }
  get releaseDate1():string{
    return this.releaseDate;
  }
  set releaseDate1(value:string){
    this.releaseDate=value;
  }
  
  onClick(){
    const product1:any={
      productId:this.productId1,
      price:this.price1,
      starRating:this.starRating1,
      productCode:this.productCode1,
      description:this.description1,
      productName:this.productName1,
      releaseDate:this.releaseDate1
    }
    this.productService.acceptProductDetails(product1).subscribe(
      tempMessage=>{
        this.addMessage="Product Added Successfully!!"; 
        
        } 
    ,
      error=>{
        this.errorMessage=error;
      }
  );
  }

  ngOnInit() {
  }

}
