import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteProductComponent implements OnInit {
  pageTitle: string='Delete This Product';
  errorMessage: string;
  deleteMessage:string;
  product:Product;
  show1:boolean=true;
  show2:boolean;
  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) { }
  productId:number;
  ngOnInit() {
    const id=this.route.snapshot.paramMap.get('id');
    const productId= +id;
    this.productId=productId;
    this.productService.getProductDetails(productId).subscribe(
      product=>{
        this.product=product;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    )
  };

  clickDelete(){
      this.productService.removeProductDetails(this.productId).subscribe(
        tempMessage=>{
        this.show1=false;
        this.show2=true;
        this.deleteMessage="Product Successfully deleted!!"; 
         //this.navigateBack();
        }
      ,
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    );
  
  }

  public navigateBack():void{
    this.router.navigate(['/products']);
  }


}
