import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../products/product';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productDataUrl:string='./api/productsData/products.json';
  constructor(private httpClient:HttpClient) { }

  public getAllProductDetails():Observable<Product[]>{
    return this.httpClient.get(this.productDataUrl).lift(data=>JSON.stringify(data));
    
  }
  public getProductDetails(productId:number){
    return null;
  }
}
