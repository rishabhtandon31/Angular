import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Product } from '../products/product';
import { Observable, observable, throwError } from 'rxjs';
import { map, catchError} from 'rxjs/operators'
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productDataUrl:string='productsData/productsList.json';
  constructor(private httpClient:HttpClient) { }

  public getAllProductsDetails():Observable<Product[]>{
    //return this.httpClient.get<Product[]>(this.productDataUrl).pipe(catchError(this.handleError));
    return this.httpClient.get<Product[]>("http://localhost:2222/onlineshop/getAllProductDetails").pipe(catchError(this.handleError));
  }
  public getProductDetails(productId:number):Observable<Product>{
    //return this.httpClient.get<Product>("http://localhost:2222/onlineshop/getProductDetails?productId="+productId).pipe(catchError(this.handleError));
    let params=new HttpParams();
    params=params.set('productId', productId.toString());
    return this.httpClient.get<Product>
    ("http://localhost:2222/onlineshop/getProductDetails",{params : params}).pipe(catchError(this.handleError));
  }

  public removeProductDetails(productId:number):Observable<void>{
    let params=new HttpParams();
    params=params.set('productId', productId.toString());
    return this.httpClient.delete<void>("http://localhost:2222/onlineshop/removeProductDetails",{params : params}).pipe(catchError(this.handleError));
  }

  public acceptProductDetails(product:any):Observable<void>{
    //let body = JSON.stringify(product);  
    //params=params.set('product', product);
    //console.log("rishabh: "+product);
    //console.log("rishabh: "+JSON.parse(product));
    return this.httpClient.post<void>("http://localhost:2222/onlineshop/acceptProductDetails",product,{}).pipe(catchError(this.handleError));;
  }

  private handleError(error: any) {
    if (error instanceof ErrorEvent) {
      console.error(`1 An ErrorEvent occurred: `, error.error.message);
      return throwError(error.error.message);
    } else if (error instanceof HttpErrorResponse) {
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was: ${error.message}`);
    } else if (error instanceof TypeError) {
      console.error(`3 TypeError has occured ${error.message}, body was: ${error.stack}`);
      return throwError(`TypeError has occured ${error.message}, body was: ${error.stack}`);
    }
  }
}
